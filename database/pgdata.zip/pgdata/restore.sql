-- \i /var/lib/postgresql/data/pgdata/restore.sql;

-- Delete data from tables
DELETE FROM company_contact;
DELETE FROM company_major;
DELETE FROM company_position;

DELETE FROM event_category;
DELETE FROM event_checkin;
DELETE FROM event_company;
DELETE FROM event_host;
DELETE FROM event_registration;

DELETE FROM favorite_events;
DELETE FROM user_company_rank;
DELETE FROM user_diet;
DELETE FROM user_major;
DELETE FROM user_occupation;
DELETE FROM user_position;

DELETE FROM test;
DELETE FROM event;
DELETE FROM swe_user;
DELETE FROM company;

DELETE FROM location;
DELETE FROM address;
DELETE FROM category;
DELETE FROM contact;
DELETE FROM diet;
DELETE FROM major;
DELETE FROM occupation;
DELETE FROM position;
DELETE FROM ucla_major;

-- Populate all tables
\copy test FROM '/var/lib/postgresql/data/pgdata/test.csv' DELIMITER ',' CSV HEADER;

\copy address (id,name,street)  FROM '/var/lib/postgresql/data/pgdata/misc/address.csv' DELIMITER ',' CSV HEADER;
\copy category (id,name)  FROM '/var/lib/postgresql/data/pgdata/misc/category.csv' DELIMITER ',' CSV HEADER;
\copy contact (id,first_name,last_name,email,phone,misc) FROM '/var/lib/postgresql/data/pgdata/misc/contact.csv' DELIMITER ',' CSV HEADER;
\copy diet (id,type)  FROM '/var/lib/postgresql/data/pgdata/misc/diet.csv' DELIMITER ',' CSV HEADER;
\copy location (id,name,address_id,description)  FROM '/var/lib/postgresql/data/pgdata/misc/location.csv' DELIMITER ',' CSV HEADER;
\copy ucla_major (id,code,major,abbreviation,department,department_abbreviation,school,division) FROM '/var/lib/postgresql/data/pgdata/misc/ucla_major.csv' DELIMITER ',' CSV HEADER;
\copy major (id,name,ucla_id) FROM '/var/lib/postgresql/data/pgdata/misc/major.csv' DELIMITER ',' CSV HEADER;
\copy occupation (id,name)  FROM '/var/lib/postgresql/data/pgdata/misc/occupation.csv' DELIMITER ',' CSV HEADER;
\copy position (id,role) FROM '/var/lib/postgresql/data/pgdata/misc/position.csv' DELIMITER ',' CSV HEADER;

\copy company (id,name,website,logo,citizenship_requirement,description) FROM '/var/lib/postgresql/data/pgdata/company/company.csv' DELIMITER ',' CSV HEADER;
\copy event (fb_id,name,starts_at,ends_at,period,week,location_id,description,fb_event,picture,is_featured)  FROM '/var/lib/postgresql/data/pgdata/event/event.csv' DELIMITER ',' CSV HEADER;
\copy swe_user (id,first_name,last_name,password,email,phone,university_id,is_admin)  FROM '/var/lib/postgresql/data/pgdata/user/swe_user.csv' DELIMITER ',' CSV HEADER;

\copy company_contact (company_id,contact_id) FROM '/var/lib/postgresql/data/pgdata/company/company_contact.csv' DELIMITER ',' CSV HEADER;
\copy company_major (company_id,major_id) FROM '/var/lib/postgresql/data/pgdata/company/company_major.csv' DELIMITER ',' CSV HEADER;
\copy company_position (company_id,position_id) FROM '/var/lib/postgresql/data/pgdata/company/company_position.csv' DELIMITER ',' CSV HEADER;

\copy event_category (event_id,category_id)  FROM '/var/lib/postgresql/data/pgdata/event/event_category.csv' DELIMITER ',' CSV HEADER;
\copy event_checkin (event_id,user_id)  FROM '/var/lib/postgresql/data/pgdata/event/event_checkin.csv' DELIMITER ',' CSV HEADER;
\copy event_company (event_id,company_id)  FROM '/var/lib/postgresql/data/pgdata/event/event_company.csv' DELIMITER ',' CSV HEADER;
\copy event_host (event_id,host_id)  FROM '/var/lib/postgresql/data/pgdata/event/event_host.csv' DELIMITER ',' CSV HEADER;
\copy event_registration (event_id,user_id,has_paid)  FROM '/var/lib/postgresql/data/pgdata/event/event_registration.csv' DELIMITER ',' CSV HEADER;

\copy favorite_events (user_id,event_id)  FROM '/var/lib/postgresql/data/pgdata/user/favorite_events.csv' DELIMITER ',' CSV HEADER;
\copy user_company_rank (user_id,company_id,rank)  FROM '/var/lib/postgresql/data/pgdata/user/user_company_rank.csv' DELIMITER ',' CSV HEADER;
\copy user_diet (user_id,diet_id)  FROM '/var/lib/postgresql/data/pgdata/user/user_diet.csv' DELIMITER ',' CSV HEADER;
\copy user_major (user_id,major_id)  FROM '/var/lib/postgresql/data/pgdata/user/user_major.csv' DELIMITER ',' CSV HEADER;
\copy user_occupation (user_id,occupation_id)  FROM '/var/lib/postgresql/data/pgdata/user/user_occupation.csv' DELIMITER ',' CSV HEADER;
\copy user_position (user_id,position_id)  FROM '/var/lib/postgresql/data/pgdata/user/user_position.csv' DELIMITER ',' CSV HEADER;

-- Modify starting value for serial sequences

-- SELECT c.relname FROM pg_class c WHERE c.relkind = 'S';
-- SELECT last_value FROM *_id_seq;

SELECT setval('company_id_seq', (SELECT MAX(id) FROM company));
SELECT setval('contact_id_seq', (SELECT MAX(id) FROM contact));
SELECT setval('ucla_major_id_seq', (SELECT MAX(id) FROM ucla_major));
SELECT setval('major_id_seq', (SELECT MAX(id) FROM major));
SELECT setval('position_id_seq', (SELECT MAX(id) FROM position));
SELECT setval('address_id_seq', (SELECT MAX(id) FROM address));
SELECT setval('location_id_seq', (SELECT MAX(id) FROM location));
SELECT setval('category_id_seq', (SELECT MAX(id) FROM category));
SELECT setval('swe_user_id_seq', (SELECT MAX(id) FROM swe_user));
SELECT setval('occupation_id_seq', (SELECT MAX(id) FROM occupation));
SELECT setval('diet_id_seq', (SELECT MAX(id) FROM diet));
